function converterParaCentimetros() {
    let metros = parseFloat(document.getElementById("metros").value);
    let centimetros = metros * 100;

    document.getElementById("resultado").innerText = `${metros} metros correspondem a ${centimetros} centímetros.`;
}