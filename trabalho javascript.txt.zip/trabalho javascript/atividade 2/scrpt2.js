function exibirNumero() {
    let numero = document.getElementById("numeroInput").value;
    document.getElementById("mensagem").innerText = `O número informado foi ${numero}`;
}