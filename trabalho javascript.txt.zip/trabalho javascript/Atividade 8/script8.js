function calcularSalario() {
    let valorHora = parseFloat(document.getElementById("valorHora").value);
    let horasMes = parseFloat(document.getElementById("horasMes").value);
    let salarioTotal = valorHora * horasMes;

    document.getElementById("resultado").innerText = `Seu salário total neste mês é de R$ ${salarioTotal.toFixed(2)}.`;
}