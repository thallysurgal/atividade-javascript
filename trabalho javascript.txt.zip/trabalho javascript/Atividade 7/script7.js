function calcularArea() {
    let lado = parseFloat(document.getElementById("lado").value);
    let area = Math.pow(lado, 2);
    let dobroArea = 2 * area;

    document.getElementById("resultado").innerText = `A área do quadrado é ${area} metros quadrados. O dobro da área é ${dobroArea} metros quadrados.`;
}