function converterParaCelsius() {
    let fahrenheit = parseFloat(document.getElementById("fahrenheit").value);
    let celsius = 5 * ((fahrenheit - 32) / 9);

    document.getElementById("resultado").innerText = `A temperatura em Celsius é aproximadamente ${celsius.toFixed(2)} graus Celsius.`;
}