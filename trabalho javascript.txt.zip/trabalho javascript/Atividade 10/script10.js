function converterParaFahrenheit() {
    let celsius = parseFloat(document.getElementById("celsius").value);
    let fahrenheit = (celsius * 9/5) + 32;

    document.getElementById("resultado").innerText = `A temperatura em Fahrenheit é aproximadamente ${fahrenheit.toFixed(2)} graus Fahrenheit.`;
}